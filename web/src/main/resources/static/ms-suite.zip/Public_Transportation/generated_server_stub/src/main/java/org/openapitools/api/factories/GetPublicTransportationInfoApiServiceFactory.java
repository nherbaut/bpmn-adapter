package org.openapitools.api.factories;

import org.openapitools.api.GetPublicTransportationInfoApiService;
import org.openapitools.api.impl.GetPublicTransportationInfoApiServiceImpl;

@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaJerseyServerCodegen", date = "2019-08-23T16:55:03.387Z[Etc/UTC]")
public class GetPublicTransportationInfoApiServiceFactory {
    private final static GetPublicTransportationInfoApiService service = new GetPublicTransportationInfoApiServiceImpl();

    public static GetPublicTransportationInfoApiService getGetPublicTransportationInfoApi() {
        return service;
    }
}
