package org.openapitools.api.factories;

import org.openapitools.api.GetParkingInformationApiService;
import org.openapitools.api.impl.GetParkingInformationApiServiceImpl;

@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaJerseyServerCodegen", date = "2019-08-23T16:55:04.350Z[Etc/UTC]")
public class GetParkingInformationApiServiceFactory {
    private final static GetParkingInformationApiService service = new GetParkingInformationApiServiceImpl();

    public static GetParkingInformationApiService getGetParkingInformationApi() {
        return service;
    }
}
