package org.openapitools.api.factories;

import org.openapitools.api.GetTrafficInformationApiService;
import org.openapitools.api.impl.GetTrafficInformationApiServiceImpl;

@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaJerseyServerCodegen", date = "2019-08-23T16:55:03.924Z[Etc/UTC]")
public class GetTrafficInformationApiServiceFactory {
    private final static GetTrafficInformationApiService service = new GetTrafficInformationApiServiceImpl();

    public static GetTrafficInformationApiService getGetTrafficInformationApi() {
        return service;
    }
}
