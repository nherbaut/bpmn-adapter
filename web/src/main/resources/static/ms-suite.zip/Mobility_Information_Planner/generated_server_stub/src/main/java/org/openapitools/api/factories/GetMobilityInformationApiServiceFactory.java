package org.openapitools.api.factories;

import org.openapitools.api.GetMobilityInformationApiService;
import org.openapitools.api.impl.GetMobilityInformationApiServiceImpl;

@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaJerseyServerCodegen", date = "2019-08-23T16:55:04.734Z[Etc/UTC]")
public class GetMobilityInformationApiServiceFactory {
    private final static GetMobilityInformationApiService service = new GetMobilityInformationApiServiceImpl();

    public static GetMobilityInformationApiService getGetMobilityInformationApi() {
        return service;
    }
}
