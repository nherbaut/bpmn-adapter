package org.openapitools.api;

import org.openapitools.model.*;
import org.openapitools.api.GetMobilityInformationApiService;
import org.openapitools.api.factories.GetMobilityInformationApiServiceFactory;

import io.swagger.annotations.ApiParam;
import io.swagger.jaxrs.*;

import org.openapitools.model.GetMobilityInfoRequest;
import org.openapitools.model.GetMobilityInfoResponse;

import java.util.Map;
import java.util.List;
import org.openapitools.api.NotFoundException;

import java.io.InputStream;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

import javax.servlet.ServletConfig;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.*;
import javax.validation.constraints.*;
import javax.validation.Valid;

@Path("/GetMobilityInformation")


@io.swagger.annotations.Api(description = "the GetMobilityInformation API")
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaJerseyServerCodegen", date = "2019-08-23T16:55:04.734Z[Etc/UTC]")
public class GetMobilityInformationApi  {
   private final GetMobilityInformationApiService delegate;

   public GetMobilityInformationApi(@Context ServletConfig servletContext) {
      GetMobilityInformationApiService delegate = null;

      if (servletContext != null) {
         String implClass = servletContext.getInitParameter("GetMobilityInformationApi.implementation");
         if (implClass != null && !"".equals(implClass.trim())) {
            try {
               delegate = (GetMobilityInformationApiService) Class.forName(implClass).newInstance();
            } catch (Exception e) {
               throw new RuntimeException(e);
            }
         } 
      }

      if (delegate == null) {
         delegate = GetMobilityInformationApiServiceFactory.getGetMobilityInformationApi();
      }

      this.delegate = delegate;
   }

    @POST
    
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "", notes = "", response = GetMobilityInfoResponse.class, tags={  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "200", response = GetMobilityInfoResponse.class) })
    public Response getMobilityInformationPost(@ApiParam(value = "" ,required=true) @NotNull @Valid GetMobilityInfoRequest getMobilityInfoRequest
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.getMobilityInformationPost(getMobilityInfoRequest, securityContext);
    }
}
