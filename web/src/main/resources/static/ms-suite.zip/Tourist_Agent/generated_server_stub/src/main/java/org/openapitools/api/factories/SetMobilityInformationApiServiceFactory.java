package org.openapitools.api.factories;

import org.openapitools.api.SetMobilityInformationApiService;
import org.openapitools.api.impl.SetMobilityInformationApiServiceImpl;

@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaJerseyServerCodegen", date = "2019-08-23T16:55:02.244Z[Etc/UTC]")
public class SetMobilityInformationApiServiceFactory {
    private final static SetMobilityInformationApiService service = new SetMobilityInformationApiServiceImpl();

    public static SetMobilityInformationApiService getSetMobilityInformationApi() {
        return service;
    }
}
