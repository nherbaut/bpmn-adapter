package org.openapitools.api;

import org.openapitools.model.*;
import org.openapitools.api.GetTripsInformationApiService;
import org.openapitools.api.factories.GetTripsInformationApiServiceFactory;

import io.swagger.annotations.ApiParam;
import io.swagger.jaxrs.*;

import org.openapitools.model.TripsRequest;
import org.openapitools.model.TripsResponse;

import java.util.Map;
import java.util.List;
import org.openapitools.api.NotFoundException;

import java.io.InputStream;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

import javax.servlet.ServletConfig;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.*;
import javax.validation.constraints.*;
import javax.validation.Valid;

@Path("/GetTripsInformation")


@io.swagger.annotations.Api(description = "the GetTripsInformation API")
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaJerseyServerCodegen", date = "2019-08-23T16:55:02.838Z[Etc/UTC]")
public class GetTripsInformationApi  {
   private final GetTripsInformationApiService delegate;

   public GetTripsInformationApi(@Context ServletConfig servletContext) {
      GetTripsInformationApiService delegate = null;

      if (servletContext != null) {
         String implClass = servletContext.getInitParameter("GetTripsInformationApi.implementation");
         if (implClass != null && !"".equals(implClass.trim())) {
            try {
               delegate = (GetTripsInformationApiService) Class.forName(implClass).newInstance();
            } catch (Exception e) {
               throw new RuntimeException(e);
            }
         } 
      }

      if (delegate == null) {
         delegate = GetTripsInformationApiServiceFactory.getGetTripsInformationApi();
      }

      this.delegate = delegate;
   }

    @POST
    
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "", notes = "", response = TripsResponse.class, tags={  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "200", response = TripsResponse.class) })
    public Response getTripsInformationPost(@ApiParam(value = "" ,required=true) @NotNull @Valid TripsRequest tripsRequest
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.getTripsInformationPost(tripsRequest, securityContext);
    }
}
