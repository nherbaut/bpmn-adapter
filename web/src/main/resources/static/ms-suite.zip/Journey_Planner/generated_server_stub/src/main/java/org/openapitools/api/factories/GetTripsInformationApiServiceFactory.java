package org.openapitools.api.factories;

import org.openapitools.api.GetTripsInformationApiService;
import org.openapitools.api.impl.GetTripsInformationApiServiceImpl;

@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaJerseyServerCodegen", date = "2019-08-23T16:55:02.838Z[Etc/UTC]")
public class GetTripsInformationApiServiceFactory {
    private final static GetTripsInformationApiService service = new GetTripsInformationApiServiceImpl();

    public static GetTripsInformationApiService getGetTripsInformationApi() {
        return service;
    }
}
